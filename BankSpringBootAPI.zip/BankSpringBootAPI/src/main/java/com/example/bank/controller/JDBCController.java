package com.example.bank.controller;

import java.util.HashMap;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank.model.entities.Client;

@RestController
public class JDBCController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/get-jdbc")
    public HashMap<String, Object> getJdbc(){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("sp_MAGANG_JOHN_CRUD");
        HashMap<String, Object> inParMap = new HashMap<String, Object>();
        inParMap.put("TransactionType", "SELECT");
        fillIn(inParMap);
        SqlParameterSource in = new MapSqlParameterSource(inParMap);

        HashMap<String, Object> outMap = (HashMap<String, Object>) simpleJdbcCall.execute(in);
        return outMap;
    }

    @GetMapping("/get-jdbc/{clientId}")
    public HashMap<String, Object> getOneJdbc(@PathVariable("clientId") UUID clientId){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("sp_MAGANG_JOHN_CRUD");
        HashMap<String, Object> inParMap = new HashMap<String, Object>();
        inParMap.put("TransactionType", "SELECT1");
        fillIn(inParMap);
        inParMap.put("clientId", clientId);
        SqlParameterSource in = new MapSqlParameterSource(inParMap);

        HashMap<String, Object> outMap = (HashMap<String, Object>) simpleJdbcCall.execute(in);
        
        return outMap;
    }

    @DeleteMapping("/del-jdbc/{clientId}")
    public HashMap<String, Object> deleteJdbc(@PathVariable("clientId") UUID clientId){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("sp_MAGANG_JOHN_CRUD");
        HashMap<String, Object> inParMap = new HashMap<String, Object>();
        inParMap.put("TransactionType", "DELETE");
        fillIn(inParMap);
        inParMap.put("clientId", clientId);
        SqlParameterSource in = new MapSqlParameterSource(inParMap);

        HashMap<String, Object> outMap = (HashMap<String, Object>) simpleJdbcCall.execute(in);
        return outMap;
    }

    @PostMapping("/post-jdbc")
    public HashMap<String, Object> postJdbc(@RequestBody Client body){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("sp_MAGANG_JOHN_CRUD");
        HashMap<String, Object> inParMap = new HashMap<String, Object>();
        inParMap.put("TransactionType", "INSERT");
        fillIn(inParMap);
        inParMap.put("number", body.getNumber());
        inParMap.put("firstName", body.getFirstName());
        inParMap.put("lastName", body.getLastName());
        SqlParameterSource in = new MapSqlParameterSource(inParMap);

        HashMap<String, Object> outMap = (HashMap<String, Object>) simpleJdbcCall.execute(in);
        return outMap;
    }

    @PutMapping("/put-jdbc/{clientId}")
    public HashMap<String, Object> putJdbc(@PathVariable("clientId") UUID clientId, @RequestBody Client body){
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("sp_MAGANG_JOHN_CRUD");
        HashMap<String, Object> inParMap = new HashMap<String, Object>();
        inParMap.put("TransactionType", "UPDATE");
        fillIn(inParMap);
        inParMap.put("clientId", clientId);
        inParMap.put("number", body.getNumber());
        inParMap.put("firstName", body.getFirstName());
        inParMap.put("lastName", body.getLastName());
        SqlParameterSource in = new MapSqlParameterSource(inParMap);

        HashMap<String, Object> outMap = (HashMap<String, Object>) simpleJdbcCall.execute(in);
        //Client client = new Client(outMap.getIndt);
        return outMap;
    }

    private HashMap<String, Object> fillIn(HashMap<String, Object> inParMap){
        inParMap.put("clientId", null);
        inParMap.put("number", null);
        inParMap.put("firstName", null);
        inParMap.put("lastName", null);
        return inParMap;
    }
}