package com.example.bank.repo;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;

import com.example.bank.model.entities.Client;

public interface MySqlRepo extends JpaRepository<Client, UUID>{
    
    @Procedure("sp_MAGANG_JOHN_CRUD")
    String getSP(String TransactionType);

    @Procedure("sp_MAGANG_JOHN_CRUD")
    List<String> postSP(String TransactionType, int number, String firstName, String lastName);

    // @Procedure("sp_MAGANG_JOHN_CRUD")
    // Client putSP(String TransactionType, UUID clientId, int number, String firstName, String lastName);

    @Procedure("sp_MAGANG_JOHN_CRUD")
    List<String> deleteSP(String TransactionType, String clientId);

    @Procedure("sp_MAGANG_JOHN_CRUD")
    void deleteSPV(String TransactionType, String clientId);

    @Procedure(procedureName = "sp_MAGANG_JOHN_CRUD", outputParameterName = "clientId")
    List<String> deleteSPO(String TransactionType, String clientId);
}